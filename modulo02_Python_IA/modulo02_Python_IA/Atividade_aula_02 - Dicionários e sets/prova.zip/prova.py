contatos = []
while True:
    continuar = input('Deseja infomar um contato, "s" para sim e "n" para não: ').lower()
    if continuar == 'n':
        break
    elif continuar != 's':
        print('Digitou errado, digite novamente!')
        continue
    nome = input('Digite o nome do contato: ')
    email = input('Digite o e-mail: ')
    telefone = input('Digite o número do telefone: ')
    
    contato = {
        'Nome': nome,
        'E-mail': email,
        'Telefone': telefone
    }
    contatos.append(contato)

for contato in contatos:
    for chave, valor in contato.items():
        print(f'{chave}: {valor}')
    print()